import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('absensi_les_v2.db'); // Saya ubah nama DB biar fresh
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    // UPDATED: Menambahkan kolom subject (mapel) dan duration (durasi)
    await db.execute('''
      CREATE TABLE students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        subject TEXT NOT NULL, 
        duration REAL NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1 
      )
    ''');

    await db.execute('''
      CREATE TABLE attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        status INTEGER NOT NULL,
        FOREIGN KEY (student_id) REFERENCES students (id)
      )
    ''');
  }

  // UPDATED: Menerima parameter subject dan duration
  Future<int> createStudent(String name, String subject, double duration) async {
    final db = await instance.database;
    return await db.insert('students', {
      'name': name, 
      'subject': subject,
      'duration': duration,
      'is_active': 1
    });
  }

  Future<List<Map<String, dynamic>>> getActiveStudents() async {
    final db = await instance.database;
    return await db.query('students', where: 'is_active = ?', whereArgs: [1]);
  }

  Future<int> softDeleteStudent(int id) async {
    final db = await instance.database;
    return await db.update('students', {'is_active': 0}, where: 'id = ?', whereArgs: [id]);
  }

  // ... (Sisa fungsi attendance biarkan sama seperti sebelumnya) ...
}