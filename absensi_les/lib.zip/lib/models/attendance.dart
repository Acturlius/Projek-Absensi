class Attendance {
  final int? id;
  final int studentId;
  final String date;
  final bool isPresent; // Status kehadiran (Hadir/Tidak)

  Attendance({
    this.id,
    required this.studentId,
    required this.date,
    required this.isPresent,
  });

  // Dari Database ke Aplikasi
  factory Attendance.fromMap(Map<String, dynamic> json) => Attendance(
    id: json['id'],
    studentId: json['student_id'],
    date: json['date'],
    // Konversi angka 1 jadi True, 0 jadi False
    isPresent: json['status'] == 1,
  );

  // Dari Aplikasi ke Database
  Map<String, dynamic> toMap() => {
    'id': id,
    'student_id': studentId,
    'date': date,
    'status': isPresent ? 1 : 0,
  };
}