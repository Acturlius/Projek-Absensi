class Student {
  final int? id;
  final String name;
  final bool isActive;

  Student({
    this.id, 
    required this.name, 
    this.isActive = true
  });

  // Fungsi 1: Mengubah Data dari Database (Map) menjadi Object Siswa
  // Database SQLite menyimpan data dalam bentuk Map (Key : Value)
  // Kita ubah jadi Object agar mudah dipakai di UI.
  // Perhatikan: SQLite menyimpan boolean sebagai angka (1/0), jadi kita konversi.
  factory Student.fromMap(Map<String, dynamic> json) => Student(
    id: json['id'],
    name: json['name'],
    // Jika is_active == 1, maka True. Selain itu False.
    isActive: json['is_active'] == 1,
  );

  // Fungsi 2: Mengubah Object Siswa menjadi Map (untuk disimpan ke Database)
  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    // Jika isActive True, simpan 1. Jika False, simpan 0.
    'is_active': isActive ? 1 : 0,
  };
}