import 'package:flutter/material.dart';
import 'screens/student_screen.dart'; // Import halaman yang tadi kita buat

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Hilangkan label 'Debug' di pojok
      title: 'Absensi Les',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const StudentScreen(), // Set halaman awal ke StudentScreen
    );
  }
}