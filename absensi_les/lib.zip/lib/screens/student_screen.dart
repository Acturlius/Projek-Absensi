import 'package:flutter/material.dart';
import '../db/database_helper.dart';

class StudentScreen extends StatefulWidget {
  const StudentScreen({super.key});

  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  List<Map<String, dynamic>> _students = [];
  bool _isLoading = true;

  // Controller untuk inputan
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _durationController = TextEditingController();
  
  // Data untuk Dropdown
  final List<String> _subjects = ['Math', 'Inggris', 'Mandarin', 'Calistung'];
  String _selectedSubject = 'Math'; // Default pilihan

  void _refreshStudents() async {
    final data = await DatabaseHelper.instance.getActiveStudents();
    setState(() {
      _students = data;
      _isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _refreshStudents();
  }

  // Fungsi Reset Form biar bersih saat dibuka lagi
  void _resetForm() {
    _nameController.clear();
    _durationController.clear();
    setState(() {
      _selectedSubject = 'Math';
    });
  }

  void _showForm() {
    _resetForm(); // Bersihkan form dulu

    showModalBottomSheet(
      context: context,
      elevation: 5,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder( // PENTING: Pakai StatefulBuilder agar Dropdown bisa berubah saat diklik
        builder: (context, setModalState) {
          return Container(
            padding: EdgeInsets.only(
              top: 15, left: 15, right: 15,
              bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // 1. Input Nama
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nama Siswa',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),

                // 2. Dropdown Mapel
                DropdownButtonFormField<String>(
                  value: _selectedSubject,
                  decoration: const InputDecoration(
                    labelText: 'Jenis Les',
                    border: OutlineInputBorder(),
                  ),
                  items: _subjects.map((String subject) {
                    return DropdownMenuItem<String>(
                      value: subject,
                      child: Text(subject),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    // Update state di dalam Modal (bukan di halaman utama)
                    setModalState(() {
                      _selectedSubject = newValue!;
                    });
                  },
                ),
                const SizedBox(height: 10),

                // 3. Input Durasi
                TextField(
                  controller: _durationController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Durasi (Jam)',
                    hintText: 'Contoh: 1.5',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),

                // Tombol Simpan
                ElevatedButton(
                  onPressed: () async {
                    if (_nameController.text.isEmpty || _durationController.text.isEmpty) {
                      return; // Jangan simpan kalau kosong
                    }
                    
                    // Proses Simpan
                    await _addItem();

                    // FIX ERROR ASYNC GAP:
                    // Cek apakah widget masih nempel di layar sebelum pakai context
                    if (!mounted) return; 
                    
                    Navigator.of(context).pop(); // Tutup form
                  },
                  child: const Text('Simpan Data'),
                )
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _addItem() async {
    await DatabaseHelper.instance.createStudent(
      _nameController.text,
      _selectedSubject,
      double.tryParse(_durationController.text) ?? 0.0, // Convert text ke angka
    );
    _refreshStudents();
  }

  void _deleteItem(int id) async {
    await DatabaseHelper.instance.softDeleteStudent(id);
    _refreshStudents();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar Murid Les')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _students.isEmpty
              ? const Center(child: Text("Belum ada siswa."))
              : ListView.builder(
                  itemCount: _students.length,
                  itemBuilder: (context, index) {
                    final student = _students[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Text(student['subject'][0]), // Huruf depan mapel
                        ),
                        title: Text(student['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text("${student['subject']} • ${student['duration']} Jam"),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteItem(student['id']),
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showForm,
        child: const Icon(Icons.add),
      ),
    );
  }
}